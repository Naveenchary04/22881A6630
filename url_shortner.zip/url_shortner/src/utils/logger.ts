export type LogLevel = 'INFO' | 'WARN' | 'ERROR' | 'DEBUG';

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  details?: any;
}

class Logger {
  private static instance: Logger;
  private logs: LogEntry[] = [];

  private constructor() {
    this.loadLogs();
  }

  static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  private loadLogs(): void {
    const savedLogs = localStorage.getItem('url_shortener_logs');
    if (savedLogs) {
      this.logs = JSON.parse(savedLogs);
    }
  }

  private saveLogs(): void {
    localStorage.setItem('url_shortener_logs', JSON.stringify(this.logs));
  }

  private log(level: LogLevel, message: string, details?: any): void {
    const logEntry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      message,
      details
    };
    
    this.logs.push(logEntry);
    this.saveLogs();
    console.log(`[${logEntry.timestamp}] [${level}] ${message}`, details || '');
  }

  info(message: string, details?: any): void {
    this.log('INFO', message, details);
  }

  warn(message: string, details?: any): void {
    this.log('WARN', message, details);
  }

  error(message: string, details?: any): void {
    this.log('ERROR', message, details);
  }

  debug(message: string, details?: any): void {
    this.log('DEBUG', message, details);
  }

  getLogs(): LogEntry[] {
    return this.logs;
  }

  clearLogs(): void {
    this.logs = [];
    localStorage.removeItem('url_shortener_logs');
  }
}

export const logger = Logger.getInstance();
